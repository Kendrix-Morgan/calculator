//
//  CaculatorTests.swift
//  CaculatorTests
//
//  Created by Kendrix on 2024/11/26.
//

import Testing
@testable import Caculator

struct CaculatorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
