//
//  MathCalculation.swift
//  Caculator
//
//  Created by Kendrix on 2024/11/26.
//

import SwiftUI

struct MathCalculation: View {
    @Environment(\.dismiss) private var dismiss
    @State private var userInput : String = ""
    @State private var userInput1 : String = ""
    @State private var result : String = ""
    @FocusState private var isFocused: Bool
    
    var body: some View {
        NavigationView {
            VStack {
                HStack(spacing:30) {
                    Text("簡単計算機")
                        .font(.system(size: 49))
                        .bold()
                        .foregroundColor(.black)
                    Button(action:{
                        dismiss()
                        SoundManager.shared.playSound(sound: "buttonsound")
                    }){
                        Image(systemName: "house.circle.fill")
                            .resizable()
                            .frame(width: 50,height: 50)
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(.white,Color(red: 255 / 255, green: 146 / 255, blue: 183 / 255))
                    }
                }.padding(.leading,50)
                
                VStack {
                    VStack {
                        TextField("1つ目の数値を入力",text: $userInput)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .font(.system(size: 25)).padding(.all,5)
                            .frame(width: 280)
                            .focused($isFocused)
                            .onSubmit {
                                    isFocused = false
                                }
                        TextField("2つ目の数値を入力",text: $userInput1)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .font(.system(size: 25)).padding(.all,5)
                            .frame(width: 280)
                            .focused($isFocused)
                            .onSubmit {
                                    isFocused = false
                                }
                            .padding()
                    }
                     .frame(width: 250,height: 100)
                   
                    Text("結果：\(result)")
                        .font(.system(size: 38))
                        .foregroundColor(.black).bold()
                        .offset(y:30)
                    
                    
                    
                    VStack(spacing:12) {
                        HStack (spacing:12){
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "+")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                    Image(systemName: "plus")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }//plus button
                            
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "-")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.red)
                                    Image(systemName: "minus")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }//minu button
                            
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "x")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.green)
                                    Image(systemName: "multiply")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }//x button
                            
                            
                        }//Button HStack
                        
                        HStack(spacing:12){
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "÷")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.orange)
                                    Image(systemName: "divide")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }// divide button
                            
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "%")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.purple)
                                    
                                    Image(systemName: "percent")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }//remainder button
                        }
                    }//buttons VStack
                    .offset(y:30)
                }
                .frame(width: 400,height: 654)
                .offset(y:140)
                
            } //VStack
            .frame(width: 400,height: 904)
            .background(MathBackground())
            .ignoresSafeArea(edges: .all)
            .background(Color.clear) // Ensure the background is tappable
            .onTapGesture {
                isFocused = false
            }
        } .navigationBarBackButtonHidden(true)
    }
    func calculate(for operation:String){
        guard let num1 = Int(userInput),
              let num2 = Int(userInput1) else{
            result = "Invalid Input"
            return
        }
        result = Calculate(num1,num2,operation: operation)
    }
}

struct MathBackground:View {
    var body: some View {
        ZStack {
            Image("joyBG1").resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 400,height: 900)
            Image("joy")
                .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 150,height: 90)
                    .offset(x:-30,y:-160)
        }
        
    }
}

#Preview {
    MathCalculation()
}

