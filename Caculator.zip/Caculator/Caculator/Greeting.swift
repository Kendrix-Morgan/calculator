//
//  Greeting.swift
//  Caculator
//
//  Created by Kendrix on 2024/11/27.
//
import SwiftUI

struct Greeting: View {
    @Environment(\.dismiss) private var dismiss
    @FocusState private var isFocused: Bool
    @State public var userinput: String = ""
    @State private var morningColor: Color = Color(red: 253 / 255, green: 231 / 255, blue: 104 / 255)
    @State private var afternoonColor: Color = Color(red: 165 / 255, green: 225 / 255, blue: 250 / 255)
    @State private var eveningColor: Color = .gray
    @State private var greetingMessage: String = "挨拶はここに表示\nされます。"  // Default greeting message
    @State private var backgroundColor: Color =  Color(red: 204 / 255, green: 159 / 255, blue: 255 / 255,opacity: 0.8)// Default background color
    
    var time: Int {
        // Check if user input is valid, otherwise use current hour
        if let userTime = Int(userinput), userTime >= 0 && userTime <= 23 {
            return userTime
        } else {
            return Calendar.current.component(.hour, from: Date()) // Default to current time
        }
    }

    var greeting: String {
        return (time >= 4 && time < 11) ? "おはよう" :
               (time >= 11 && time < 17) ? "こんにちは" : "こんばんは"
    }

    var setBackgroundColor: Color {
        return (time >= 4 && time < 11) ? morningColor :
               (time >= 11 && time < 17) ? afternoonColor : eveningColor
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 45) {
                
                    HStack(spacing: 20)  {
                        Text("挨拶アプリ")
                            .font(.system(size: 49))
                            .bold()
                            .foregroundColor(.black)
                        Button(action:{
                            
                            SoundManager.shared.playSound(sound: "buttonsound")
                            dismiss()
                        }){
                            Image(systemName: "house.circle.fill")
                                .resizable()
                                .frame(width: 50,height: 50)
                                .symbolRenderingMode(.palette)
                                .foregroundStyle(.white,Color(red: 255 / 255, green: 146 / 255, blue: 183 / 255))
                        }
                    }.padding(.leading,70)
                    .padding(.top,20)
                Text("現在時刻: \(Calendar.current.component(.hour, from: Date())):\(String(format: "%02d", Calendar.current.component(.minute, from: Date())))")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.black)
                    .padding(.trailing, 200)
                
                HStack{
                    Image("Fear")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 100,height: 100)
                    
                    Text(greetingMessage)  // Show the greeting based on user input or current time
                        .font(.title2)
                        .foregroundColor(.black)
                  
                }.frame(width: 350,height: 200)
                    .background(backgroundColor)
                    .cornerRadius(20)
                    .shadow(radius: 6,x:5,y:4)
              
                
                
                VStack(spacing: 15) {
                   HStack {
                        TextField("時刻を入力(0~23)", text: $userinput)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .font(.system(size: 25))
                            .frame(width: 210, height: 70)
                            .cornerRadius(8)
                            .focused($isFocused)
                            .onSubmit {
                                isFocused = false
                            }
                        
                        Button {
                            SoundManager.shared.playSound(sound: "buttonsound")
                            // Update the greeting and background color based on user input time
                            if let userTime = Int(userinput), userTime >= 0 && userTime <= 23 {
                                greetingMessage = greeting
                                backgroundColor = setBackgroundColor  // Update the background color
                            } else {
                                greetingMessage = "無効な時間です。\n0から23までの数字を\n入力してください。"
                            }
                        } label: {
                            ZStack(alignment: .center) {
                                RoundedRectangle(cornerRadius: 15)
                                    .frame(width: 150, height: 50)
                                    .foregroundStyle(.green)
                                Text("指定時刻で挨拶")
                                    .font(.system(size: 20))
                                    .foregroundColor(.white)
                            }
                        }
                    }  // User input HStack
                    
                    Button {
                        SoundManager.shared.playSound(sound: "buttonsound")
                        // Update the greeting and background color based on current time
                        let currentTime = Calendar.current.component(.hour, from: Date())
                        greetingMessage = (currentTime >= 4 && currentTime < 11) ? "おはよう" :
                        (currentTime >= 11 && currentTime < 17) ? "こんにちは" : "こんばんは"
                        backgroundColor = (currentTime >= 4 && currentTime < 11) ? morningColor :
                        (currentTime >= 11 && currentTime < 17) ? afternoonColor : eveningColor
                    } label: {
                        ZStack(alignment: .center) {
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 180, height: 70)
                                .foregroundStyle(.blue)
                            Text("現在時刻で挨拶")
                                .font(.system(size: 25))
                                .foregroundColor(.white)
                        }
                    }
                    
                    HStack(spacing:60) {
                        Text("背景色の設定")
                            .font(.system(size: 33))
                            .foregroundColor(.black)
                        Button(action:{
                            SoundManager.shared.playSound(sound: "buttonsound")
                            backgroundColor =  Color(red: 204 / 255, green: 159 / 255, blue: 255 / 255,opacity: 0.8)// Default background color
                        morningColor = .yellow.opacity(0.8)
                        afternoonColor = Color(red: 165 / 255, green: 225 / 255, blue: 250 / 255)
                            eveningColor = .gray.opacity(0.6)
                            
                        }){
                            VStack {
                                Image("reset")
                                    .resizable().scaledToFit()
                                    .frame(width: 30,height: 30)
                                Text("RESET")
                                  .font(.system(size: 10))
                                 .foregroundColor(.black).bold()
                                
                            }
                        }.offset(y:5)
                    }.padding(.leading,80)
                    
                    
                    VStack {
                        ColorPicker("朝の背景色", selection: $morningColor)
                        
                        ColorPicker("昼の背景色", selection: $afternoonColor)
                        
                        ColorPicker("夜の背景色", selection: $eveningColor)
                        
                    }.font(.system(size: 25))
                        .foregroundColor(.black)
                        .padding()
                    
                } .frame(height: 350)
                
            }
            .frame(width: 405, height: 904)
            .background(GreetingBackground())
            .ignoresSafeArea(edges: .all)
            .transition(.opacity)  // Add transition effect
            .animation(.easeInOut(duration: 0.5), value: backgroundColor)  // Animate the background color change
            .background(Color.clear) // Ensure the background is tappable
            .onTapGesture {
                isFocused = false
            }
         } .navigationBarBackButtonHidden(true)
    }
}
struct GreetingBackground:View {
    var body: some View {
        ZStack {
            Image("FearBG").resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 400,height: 901)
          
        }
        
    }
}


#Preview {
    Greeting()
}
