import SwiftUI

struct ContentView: View {
    
    let photoData = ["joy", "embarrassment", "sadness","Anxiety","Fear"]
    let rectangleColors: [Color] = [
        .yellow,
        Color(red: 255 / 255, green: 146 / 255, blue: 183 / 255),
        Color(red: 98 / 255, green: 180 / 255, blue: 244 / 255),
        .orange,
        Color(red: 204 / 255, green: 159 / 255, blue: 255 / 255)
    ]
    let pageName = ["簡単計算機", "⽐較演算⼦", "割引判定シール","数字リスト生成","挨拶アプリ"]

    @State private var selectedView: Int = 0

    var body: some View {
        NavigationView {
            ZStack {
                // Change the background view based on the selected photo
                switch selectedView {
                case 0:
                    JoyView()
                case 1:
                    EmbarrassmentView()
                case 2:
                    SadnessView()
                case 3:
                    AnxietyView()
                case 4:
                    FearView()
                default:
                    Color(.systemBackground)
                }

                
                VStack {
                 
                    // Navigation link for the page name
                    NavigationLink(
                        destination: getPageView(for: selectedView),
                        label: {
                            Text(pageName[selectedView])
                                .font(.system(size: 45)).bold()
                                .foregroundColor(.black)
                                
                        }
                    ).simultaneousGesture(TapGesture().onEnded {
                        SoundManager.shared.playSound(sound: "buttonsound")
                    })
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 20) {
                            ForEach(0..<photoData.count, id: \.self) { index in
                                ZStack {
                                    RoundedRectangle(cornerRadius: 15)
                                        .fill(rectangleColors[index])
                                        .opacity(0.9)
                                        .frame(width: 220, height: 250)

                                    Image(photoData[index])
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .shadow(radius: 3, x: 3, y: 2)
                                        .frame(width: 130, height: 90)
                                        .offset(y: -15)
                                }
                                .onTapGesture {
                                    // Update selectedView to show the corresponding background
                                    selectedView = index
                                    SoundManager.shared.playSound(sound: "buttonsound")
                                    
                                }
                            }
                        }
                       .padding()
                    } // ScrollView
                   
                } .offset(y: 220)
                
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.white)
            .animation(.easeInOut, value: selectedView)
            .transition(.opacity)
            .onAppear{
                AudioPlayerManager.shared.playMusic(filename: "insideout")
                AudioPlayerManager.shared.player?.volume = 0.7
            }
        }
    }

    // Helper function to return the appropriate page
    @ViewBuilder
    func getPageView(for index: Int) -> some View {
        switch index {
        case 0:
            MathCalculation()
        case 1:
            Comparison()
        case 2:
            Discount()
        case 3:
            RangeOperator()
        case 4:
            Greeting()
        default:
            Text("Page not found")
        }
    }
}



// Example background views
struct JoyView: View {
    var body: some View {
        ZStack {
            HStack {
                Image("joy")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 150, height: 90)
                Text("JOY")
                    .offset(x: 30, y: 120)
                    .bold()
                    .foregroundColor(.black)
            }
            .offset(y: -150)
            Image("book")
                .resizable()
                .frame(width: 100,height: 100)
                .offset(x:120,y:-280)
        }   .frame(maxWidth: .infinity, maxHeight: .infinity)
     
    }
}

struct EmbarrassmentView: View {
    var body: some View {
            HStack {
                Image("embarrassment")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 190, height: 90)
                Text("EMBARRASSMENT")
                    .offset(x: 10, y: 130)
                    .bold()
                    .foregroundColor(.black)
            }
            .offset(y: -150)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct SadnessView: View {
    var body: some View {
            HStack {
                Image("sadness")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 250, height: 90)
                Text("SADNESS")
                    .offset(x: -20, y: 90)
                    .bold()
                    .foregroundColor(.black)
            }
            .offset(y: -150)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
struct AnxietyView:View {
    var body: some View {
        HStack {
            Image("Anxiety")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 190, height: 90)
            Text("ANXIETY")
                .offset(x: -20, y: 130)
                .bold()
                .foregroundColor(.black)
        }
        .offset(y: -150)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct FearView:View {
    var body: some View {
        HStack {
            Image("Fear")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 200, height: 90)
            Text("FEAR")
                .offset(x: -20, y: 130)
                .bold()
                .foregroundColor(.black)
        }
        .offset(y: -160)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    ContentView()
}
