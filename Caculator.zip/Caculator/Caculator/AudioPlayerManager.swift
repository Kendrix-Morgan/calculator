//
//  AudioPlayerManager.swift
//  videoTesting
//
//  Created by Kendrix on 2024/08/30.

import AVKit
import Foundation
import AVFoundation

class AudioPlayerManager: ObservableObject {
    @Published var isMusicEnabled: Bool = true
    static let shared = AudioPlayerManager() // Singleton instance
    var player: AVQueuePlayer?
    var looper: AVPlayerLooper?
    public var currentSong: String?
    public var currentTime: CMTime? // Track the current playback time

    public init() { // Prevents instantiation outside this class
        // Configure audio session
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to set up audio session: \(error)")
        }
    }

    
    // Play music and resume from previous position if needed
    func playMusic(filename: String) {
        // Avoid restarting the song if it's already playing
        if currentSong == filename, let player = player, player.timeControlStatus == .playing {
            return
        }

        // Load the audio file from the bundle
        guard let url = Bundle.main.url(forResource: filename, withExtension: "mp3") else {
            print("Error: Music file not found")
            return
        }

        let item = AVPlayerItem(url: url)
        self.player = AVQueuePlayer(playerItem: item)
        self.looper = AVPlayerLooper(player: self.player!, templateItem: item)

        // Resume from the last known position if available
        if let time = currentTime {
            player?.seek(to: time)
        }

        player?.play() // Start playing the music
        currentSong = filename // Track the currently playing song
        print("Playing: \(filename)") // For debugging
    }

    func saveCurrentTime() {
        // Save the current playback time
        currentTime = player?.currentTime()
    }

    func play() {
        player?.play()
    }
    
    func pause() {
        saveCurrentTime() // Save the current time before pausing
        player?.pause()
    }

    func resume() {
        // Ensure we only resume if music is enabled
        guard isMusicEnabled else { return }
        
        if let time = currentTime {
            player?.seek(to: time)
        }
        player?.play()
    }

    func stop() {
        player?.pause()
        player = nil // Clear the player when stopping
        currentSong = nil // Clear the current song
        currentTime = nil // Reset current time
    }
}


class SoundManager {
    static let shared = SoundManager() // Singleton instance for global access
    private var audioPlayer: AVAudioPlayer?
    private var soundEnabled: Bool = true // Track sound state

    // Private initializer to enforce singleton usage
    private init() {}

    // Function to enable/disable sound
    func setSoundEnabled(_ isEnabled: Bool) {
        soundEnabled = isEnabled
    }

    // Function to play sound by file name
    func playSound(sound: String, fileType: String = "mp3") {
        guard soundEnabled else {
            print("Sound is disabled.")
            return
        }

        if let soundURL = Bundle.main.url(forResource: sound, withExtension: fileType) {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
                audioPlayer?.play()
                print("Playing sound: \(sound)")
            } catch {
                print("Error: Could not play sound - \(error.localizedDescription)")
            }
        } else {
            print("Error: Sound file \(sound).\(fileType) not found")
        }
    }
}
