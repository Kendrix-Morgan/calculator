//
//  Caculation.swift
//  Caculator
//
//  Created by Kendrix on 2024/11/26.
//

import Foundation

func Calculate(_ num1: Int, _ num2: Int, operation: String) -> String {
    var result: String
    
    switch operation {
    case "+":
        result = String(num1 + num2)
    case "-":
        result = String(num1 - num2)
    case "x":
        result = String(num1 * num2)
    case "÷":
        if num2 != 0 {
            result = String(num1 / num2)
        } else {
            return "Cannot divide by zero"
        }
    case "%":
        if num2 != 0 {
            result = String(num1 % num2)
        } else {
            return "Cannot divide by zero"
        }
    case ">":
        result = num1 > num2 ? "真です。" : "偽です。"
    case "<":
        result = num1 < num2 ? "真です。" : "偽です。"
    case "≥":
        result = num1 >= num2 ? "真です。" : "偽です。"
    case "≤":
        result = num1 <= num2 ? "真です。" : "偽です。"
    case "==":
        result = num1 == num2 ? "真です。" : "偽です。"
    case "≠":
        result = num1 != num2 ? "真です。" : "偽です。"
    default:
        return "Invalid Operation"
    }
    
    // Return the formatted string, including the operation and result
    return "\(num1) \(operation) \(num2) = \(result)"
}
