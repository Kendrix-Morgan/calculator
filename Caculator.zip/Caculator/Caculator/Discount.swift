//
//  Discount.swift
//  Caculator
//
//  Created by Kendrix on 2024/11/26.
//

import SwiftUI

struct Discount: View {
    @Environment(\.dismiss) private var dismiss
    @State private var userInput: String = ""
    @State private var result: String = ""
    @State private var isMember: Bool = false
    @State private var isFirstMember: Bool = false
    @FocusState private var isFocused: Bool
    
    
    var body: some View {
        NavigationView {
            VStack {
                HStack(spacing:20) {
                    Text("割引判定シール")
                        .font(.system(size: 40))
                        .bold()
                        .foregroundColor(.black)
                    Button(action:{
                        SoundManager.shared.playSound(sound: "buttonsound")
                        dismiss()
                    }){
                        Image(systemName: "house.circle.fill")
                            .resizable()
                            .frame(width: 50,height: 50)
                            .symbolRenderingMode(.palette)
                            .foregroundStyle( .white, Color(red: 98 / 255, green: 180 / 255, blue: 244 / 255))
                    }
                }.padding(.leading,50)
                
                VStack(spacing:30){
                  
                    // Membership Toggle
                    Toggle("会員ですか？", isOn: $isMember)
                        .font(.system(size: 28))
                        .frame(width: 280).foregroundColor(.black)
                    
                    
                    // FirstTime Toggle
                    Toggle("初回利用ですか？", isOn: $isFirstMember)
                        .font(.system(size: 28))
                        .frame(width: 280).foregroundColor(.black)
                     
                    
                    // Age Input
                    TextField("年齢を入力してください", text: $userInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                        .font(.system(size: 25))
                        .frame(width: 280)
                        .focused($isFocused)
                        .onSubmit {
                                isFocused = false
                            }
                    
                    // Result Text
                    Text("結果：\(result)")
                        .font(.system(size: 28))
                        .foregroundColor(.black).padding()
                    
                    // Button to Calculate Discount Eligibility
                    Button(action: {
                        SoundManager.shared.playSound(sound: "buttonsound")
                        calculateDiscount()
                    }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 150, height: 70)
                                .foregroundStyle(.blue)
                            Text("割引判定")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                        }
                    }
                    
                    
                }//VStack
                .frame(height: 654)
                .offset(y:150)
                
            } .frame(width: 400,height: 904)
                .background(DiscountBackground())
                .ignoresSafeArea(edges: .all)
                .background(Color.clear) // Ensure the background is tappable
                .onTapGesture {
                    isFocused = false
                }
        } .navigationBarBackButtonHidden(true)
           
    }
    
    // Function to Determine Discount Eligibility
    func calculateDiscount() {
        guard let age = Int(userInput), age >= 0 else {
            result = "有効な年齢を入力してください"
            return
        }
        
        if (age >= 18 && isMember) || age < 18 || age >= 65 || isFirstMember{
            result = "割引が適用されます"
        }
        else {
            result = "割引は適用されません"
        }
    }
}
struct DiscountBackground:View {
    var body: some View {
        ZStack {
            Image("sadnessBG").resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 400,height: 904)
            Image("sadness")
                .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 280,height: 100)
                    .shadow(radius: 7,x:10,y:10)
                    .offset(x:-30,y:-160)
        }
        
    }
}

#Preview {
    Discount()
}
