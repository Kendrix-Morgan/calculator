//
//  Comparison.swift
//  Caculator
//
//  Created by Kendrix on 2024/11/26.
//

import SwiftUI

struct Comparison: View {
    @Environment(\.dismiss) private var dismiss
    @State private var userInput : String = ""
    @State private var userInput1 : String = ""
    @State private var result : String = ""
    @FocusState private var isFocused: Bool
    
    var body: some View {
        NavigationView {
            VStack {
                HStack(spacing:30) {
                    Text("⽐較演算⼦")
                        .font(.system(size: 49))
                        .bold()
                        .foregroundColor(.black)
                    Button(action:{
                        SoundManager.shared.playSound(sound: "buttonsound")
                        dismiss()
                    }){
                        Image(systemName: "house.circle.fill")
                            .resizable()
                            .frame(width: 50,height: 50)
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(.white,Color(red: 255 / 255, green: 146 / 255, blue: 183 / 255))
                    }
                }.padding(.leading,50)
                
                VStack{
                    
                    VStack(spacing:10) {
                        TextField("1つ目の数値を入力",text: $userInput)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .font(.system(size: 25)).padding(.all,5)
                            .frame(width: 280)
                            .focused($isFocused)
                            .onSubmit {
                                    isFocused = false
                                }
                        TextField("2つ目の数値を入力",text: $userInput1).focused($isFocused)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .font(.system(size: 25)).padding(.all,5)
                            .frame(width: 280)
                            .focused($isFocused)
                            .padding()
                            .onSubmit {
                                    isFocused = false
                                }
                    }.frame(width: 250,height: 100)
              
                        .padding()
                    
                    
                    Text("結果：\(result)")
                        .font(.system(size: 30))
                        .foregroundColor(.black).padding()
                    
                    VStack(spacing:10){
                        HStack(spacing:10) {
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "<")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.blue)
                                    Image(systemName: "lessthan")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                                
                            }//lessthan
                            
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: ">")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.red)
                                    Image(systemName: "greaterthan")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }//greaterthan
                            
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "==")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.purple)
                                    HStack (spacing:0.9){
                                        Image(systemName: "equal")
                                        Image(systemName: "equal")
                                    } .font(.system(size: 28))
                                        .foregroundColor(.white)
                                }
                                
                            }//equal
                            
                        }//Button first row
                        
                        HStack(spacing:10) {
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "≤")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.green)
                                    Image(systemName: "lessthanorequalto")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                                
                            }//lessthanorequalto
                            
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "≥")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.orange)
                                    Image(systemName: "greaterthanorequalto")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }//greaterthanorequalto
                            
                            Button(action:{
                                SoundManager.shared.playSound(sound: "buttonsound")
                                calculate(for: "≠")
                            }){
                                ZStack(alignment:.center) {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 70,height: 70)
                                        .foregroundStyle(.gray)
                                    Image(systemName: "notequal")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                            }//notequal
                        }//Button second row
                        
                    }//buttons VStack
                    .offset(y:50)
                    
                    
                }//VStack
                .offset(y:120)
                .frame(width: 400,height: 654)
                
                
                
            }  .frame(width: 400,height: 904)
                .background(ComparisonBackground())
                .ignoresSafeArea(edges: .all)
                .background(Color.clear) // Ensure the background is tappable
                .onTapGesture {
                    isFocused = false
                }
        } .navigationBarBackButtonHidden(true)
    }
    

    func calculate(for operation:String){
        guard let num1 = Int(userInput),
              let num2 = Int(userInput1) else{
            result = "Invalid Input"
            return
        }
        result = Calculate(num1,num2,operation: operation)
    }
    
}
struct ComparisonBackground:View {
    var body: some View {
        ZStack {
            Image("embarrass").resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 400,height: 901)
            Image("embarrassment")
                .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 160,height: 100)
                    .shadow(radius: 7,x:10,y:10)
                    .offset(x:-55,y:-160)
        }
        
    }
}

#Preview {
    Comparison()
}
