//
//  RangeOperator.swift
//  Calculator
//
//  Created by Kendrix on 2024/11/27.
//

import SwiftUI

struct RangeOperator: View {
    @Environment(\.dismiss) private var dismiss
    @FocusState private var isFocused: Bool
    @State private var isListShow : Bool = false
    @State private var userInput : String = ""
    @State private var userInput1 : String = ""
    @State private var result : String = ""
    @State private var selectedOption = "全て"
    let pickerData = ["全て", "偶数", "奇数"]
    
    var filterNumber:[Int] {
        guard let start = Int(userInput),
              let   end = Int(userInput1), start <= end
        else{
            return []// Return an empty array if input is invalid
        }
        let range = Array(start...end)
        switch selectedOption{
        case "偶数":
            return range.filter { $0 % 2 == 0 }
        case "奇数":
            return range.filter { $0 % 2 != 0 }
        default: return range
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    HStack(spacing:30) {
                        Text("数字リスト生成")
                            .font(.system(size: 40))
                            .bold()
                            .foregroundColor(.black)
                        Button(action:{
                            SoundManager.shared.playSound(sound: "buttonsound")
                            dismiss()
                        }){
                            Image(systemName: "house.circle.fill")
                                .resizable()
                                .frame(width: 50,height: 50)
                                .symbolRenderingMode(.palette)
                                .foregroundStyle(.white,Color(red: 255 / 255, green: 146 / 255, blue: 183 / 255))
                        }
                    }.padding(.leading,30)
                        .padding(.top,80)
                    
                    
                    HStack {
                        TextField("1つ目数値",text: $userInput)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .font(.system(size: 25)).padding(.all,5)
                            .frame(width: 150)
                            .focused($isFocused)
                            .onSubmit {
                                isFocused = false
                            }
                        TextField("２つ目数値",text: $userInput1)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .font(.system(size: 25)).padding(.all,5)
                            .frame(width: 150)
                            .focused($isFocused)
                            .onSubmit {
                                isFocused = false
                            }
                    }.padding(.top,40)
                    
                    Picker("選択", selection: $selectedOption) {
                        ForEach(pickerData, id: \.self) { option in
                            Text(option)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()
                    .onChange(of: selectedOption) {
                        SoundManager.shared.playSound(sound: "buttonsound")
                    }
                    
                    ZStack{
                       
                        if isListShow{
                            
                            List(filterNumber,id:\.self){number in
                                Text("\(number)")
                            }.listStyle(.plain)
                                .frame(width: 360,height: 380)
                            
                        }
                        Image("Anxiety")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 150,height: 100)
                            .shadow(radius: 5,x:3,y:3)
                            .padding(.leading,230)
                            .padding(.bottom,70)
                           
                            
                    }.frame(height: 450)
                        .offset(y:-25)
                    Spacer()
                }//Vstack
                .frame(width: 400,height: 644)
                
                HStack(spacing:30) {
                        Button {
                            SoundManager.shared.playSound(sound: "buttonsound")
                            isListShow = true
                        } label: {
                            ZStack(alignment:.center) {
                                RoundedRectangle(cornerRadius: 15)
                                    .frame(width: 130,height: 70)
                                    .foregroundStyle(.green)
                                Text("生成する")
                                    .font(.system(size: 30)).bold()
                                    .foregroundColor(.white)
                                
                            }
                        }//生成 button
                        Button {
                            SoundManager.shared.playSound(sound: "buttonsound")
                            userInput = ""
                            userInput1 = ""
                            isListShow = false
                        } label: {
                            ZStack(alignment:.center) {
                                RoundedRectangle(cornerRadius: 15)
                                    .frame(width: 130,height: 70)
                                    .foregroundStyle(.red)
                                Text("リセット")
                                    .font(.system(size: 30)).bold()
                                    .foregroundColor(.white)
                                
                            }
                        }
                    }
                    
                
            }.frame(width: 400,height: 904)
              .background(RangeOperatorBackground())
              .ignoresSafeArea(edges: .all)
              .background(Color.clear)
              .onTapGesture {
                    isFocused = false
                }
        }//Navi
        .navigationBarBackButtonHidden(true)
       
    }
}

struct RangeOperatorBackground:View {
    var body: some View {
        VStack {
            Image("AnxietyBG").resizable()
                .scaleEffect(x:1.01,y:1)
                .padding(.bottom,10)
          
        }
        
    }
}


#Preview {
    RangeOperator()
}
