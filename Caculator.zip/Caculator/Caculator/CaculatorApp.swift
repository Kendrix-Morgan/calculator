//
//  CaculatorApp.swift
//  Caculator
//
//  Created by Kendrix on 2024/11/26.
//

import SwiftUI

@main
struct CaculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
